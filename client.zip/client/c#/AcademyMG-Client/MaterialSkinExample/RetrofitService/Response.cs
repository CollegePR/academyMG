﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaterialSkinExample.RetrofitService
{
    public class Response
    {
        public bool status { get; set; }
        public bool flag { get; set; }
    }
}
