package insurance.manager.appplepi.com.insurancemg.Activity;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by Sunrin on 2016-03-28.
 */
public class AddActivity extends AppCompatActivity{

}
