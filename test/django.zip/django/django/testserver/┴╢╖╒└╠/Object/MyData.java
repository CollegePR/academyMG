package insurance.manager.appplepi.com.insurancemg.Object;

/**
 * Created by Sunrin on 2016-03-21.
 */
public class MyData{
    public String text;
    public int img;
    public MyData(String text, int img){
        this.text = text;
        this.img = img;
    }
}